﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Budweg2._1.Model
{
    public enum Role
    {
        Foreman,
        AssemblyWorker,
        QualityManager
    }
}
